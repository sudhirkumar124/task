package com.danske.bank.util;

import com.danske.bank.dto.AccountDTO;
import com.danske.bank.entity.Account;

public class AccountMapper {

	// Utility method to map Account entity to AccountDTO
	public static AccountDTO mapAccountToDTO(Account account) {
		AccountDTO accountDTO = new AccountDTO();
		accountDTO.setCustomerId(account.getId());
		accountDTO.setAccountType(account.getAccountType().name());
		accountDTO.setAccountNumber(account.getAccountNumber());
		accountDTO.setBalance(account.getBalance());
		return accountDTO;
	}

}
