package com.danske.bank.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.danske.bank.dto.AccountDTO;
import com.danske.bank.dto.TransactionDTO;
import com.danske.bank.service.AccountService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/v1/accounts")
public class AccountResource {

	@Autowired
	private AccountService accountService;

	@PostMapping
	public ResponseEntity<AccountDTO> createAccount(@Valid @RequestBody AccountDTO accountDto) {
		AccountDTO createdAccount = accountService.createAccount(accountDto);
		return ResponseEntity.ok(createdAccount);
	}

	@PostMapping("/{accountNumber}/deposit")
	public ResponseEntity<AccountDTO> depositMoney(@PathVariable String accountNumber,
			@RequestBody TransactionDTO transactionDTO) {
		AccountDTO updatedAccount = accountService.depositMoney(accountNumber, transactionDTO.getAmount());
		return ResponseEntity.ok(updatedAccount);
	}

	@PostMapping("/{accountNumber}/withdraw")
	public ResponseEntity<AccountDTO> withdrawMoney(@PathVariable String accountNumber,
			@RequestBody TransactionDTO transactionDTO) {
		AccountDTO updatedAccount = accountService.withdrawMoney(accountNumber, transactionDTO.getAmount());
		return ResponseEntity.ok(updatedAccount);
	}

	@GetMapping("/{accountNumber}/balance")
	public ResponseEntity<Double> getAvailableBalance(@PathVariable String accountNumber) {
		double balance = accountService.getAvailableBalance(accountNumber);
		return ResponseEntity.ok(balance);
	}

	@GetMapping("/{accountNumber}/transactions")
	public ResponseEntity<List<TransactionDTO>> getLast10Transactions(@PathVariable String accountNumber) {
		List<TransactionDTO> transactions = accountService.getLast10Transactions(accountNumber);
		return ResponseEntity.ok(transactions);
	}

}
