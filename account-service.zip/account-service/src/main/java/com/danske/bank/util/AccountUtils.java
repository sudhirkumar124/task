package com.danske.bank.util;

import java.util.Random;

public class AccountUtils {

	public static String generateRandomAccountNumber() {
		Random random = new Random();
		// Generate a random long value between 1000000000 and 9999999999
		long randomNumber = 1000000000L + random.nextLong() % (10000000000L - 1000000000L);
		// positive number only
		return "" + Math.abs(randomNumber);
	}

}
