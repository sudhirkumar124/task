package com.danske.bank.service;

import java.util.List;

import com.danske.bank.dto.AccountDTO;
import com.danske.bank.dto.TransactionDTO;

public interface AccountService {

	/**
	 * Creates a new savings account for the customer.
	 *
	 * @param accountDTO for which account needs to be created
	 * @return The created AccountDTO.
	 */
	AccountDTO createAccount(AccountDTO accountDTO);

	/**
	 * Deposits money to the specified account.
	 *
	 * @param accountNumber for which money needs to be deposited.
	 * @param amount(money) to be deposited.
	 * @return updated AccountDTO.
	 */
	AccountDTO depositMoney(String accountNumber, double amount);

	/**
	 * Withdraws money from the provided account.
	 *
	 * @param accountNumber from which money needs to be withdrawn.
	 * @param amount(money) to be withdrawn.
	 * @return updated AccountDTO.
	 */
	AccountDTO withdrawMoney(String accountNumber, double amount);

	/**
	 * Retrieves the available balance for the provided account.
	 *
	 * @param accountNumber for which available balance needs to be fetched.
	 * @return available balance as a double value.
	 */
	double getAvailableBalance(String accountNumber);

	/**
	 * Retrieves the last 10 transactions for the provided account.
	 *
	 * @param accountNumber for which transactions need to be fetched.
	 * @return A list of TransactionDTO representing the last 10 transactions.
	 */
	List<TransactionDTO> getLast10Transactions(String accountNumber);
}
