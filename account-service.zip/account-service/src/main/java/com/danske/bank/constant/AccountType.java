package com.danske.bank.constant;

public enum AccountType {
	SAVINGS, FIXED, CURRENT;

	public static AccountType parse(String type) {
		return AccountType.valueOf(type.toUpperCase());

	}
}