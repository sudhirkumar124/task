package com.danske.bank.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.danske.bank.constant.AccountType;
import com.danske.bank.dto.AccountDTO;
import com.danske.bank.dto.TransactionDTO;
import com.danske.bank.entity.Account;
import com.danske.bank.exception.AccountServiceException;
import com.danske.bank.repository.AccountRepository;
import com.danske.bank.util.AccountMapper;
import com.danske.bank.util.AccountUtils;

import jakarta.transaction.Transaction;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountRepository accountRepository;

	// temporary storage, replace with accountRepository for real db in future
	private Map<String, Account> accounts = new HashMap<>();
	private Map<String, List<Transaction>> transactions = new HashMap<>();

	@Override
	@Transactional
	public AccountDTO createAccount(AccountDTO dto) {

		try {
			Account account = new Account();

			String accountNumber = AccountUtils.generateRandomAccountNumber();
			double initialBalance = 0.0;
			account.setId(100 + (long) (Math.random() * 899));
			account.setAccountNumber(accountNumber);
			account.setBalance(initialBalance);
			AccountType accountType = AccountType.valueOf(dto.getAccountType().toUpperCase());
			account.setAccountType(accountType);

			// Validate allowed values for accountType: SAVINGS, FIXED, CURRENT
			switch (accountType) {
			case SAVINGS, FIXED, CURRENT -> accounts.put(accountNumber, account);

			default -> throw new AccountServiceException("Invalid account type: " + dto.getAccountType());
			}

			return AccountMapper.mapAccountToDTO(account);
		} catch (Exception e) {
			throw new AccountServiceException("Invalid input: " + e.getMessage());
		}

	}

	@Override
	public AccountDTO depositMoney(String accountNumber, double amount) {
		// Implement the logic to deposit money to the provided account and update the
		// balance
		// Save the transaction details to the TransactionRepository
		// Return the updated AccountDTO
		return null;
	}

	@Override
	public AccountDTO withdrawMoney(String accountNumber, double amount) {
		// Implement the logic to withdraw money from the specified account and update
		// the balance
		// Save the transaction details to the TransactionRepository
		// Return the updated AccountDTO
		return null;
	}

	@Override
	public double getAvailableBalance(String accountNumber) {
		// Implement the logic to retrieve the available balance for the provided
		// account
		// Return the available balance as a double value
		return 0;
	}

	@Override
	public List<TransactionDTO> getLast10Transactions(String accountNumber) {
		// Implement the logic to retrieve the last 10 transactions for the provided
		// account
		// from the TransactionRepository
		// Return the list of TransactionDTOs
		return null;

	}
}
