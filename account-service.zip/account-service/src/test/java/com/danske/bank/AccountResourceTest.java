package com.danske.bank;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.danske.bank.dto.AccountDTO;
import com.danske.bank.resource.AccountResource;

@SpringBootTest
public class AccountResourceTest {

	@Autowired
	private AccountResource accountResource;

	@Test
	public void testCreateAccount() {
		AccountDTO dto = new AccountDTO();

		// Test with valid account type: SAVINGS, expected to pass
		dto.setAccountType("savings");
		ResponseEntity<AccountDTO> accountDTO = accountResource.createAccount(dto);

		assertNotNull(accountDTO);
		assertEquals(10, accountDTO.getBody().getAccountNumber().length());
		assertEquals(0.0, accountDTO.getBody().getBalance());

	}

}
