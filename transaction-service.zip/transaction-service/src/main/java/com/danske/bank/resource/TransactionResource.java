package com.danske.bank.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.danske.bank.dto.TransactionDTO;
import com.danske.bank.service.TransactionService;

@RestController
@RequestMapping("/v1/transactions")
public class TransactionResource {

	@Autowired
	private TransactionService transactionService;

	@PostMapping
	public ResponseEntity<TransactionDTO> createTransaction(@RequestBody TransactionDTO transactionDTO) {
		TransactionDTO createdTransaction = transactionService.createTransaction(transactionDTO);
		return ResponseEntity.ok(createdTransaction);
	}

	@GetMapping("/{accountNumber}/last10")
	public ResponseEntity<List<TransactionDTO>> getLast10Transactions(@PathVariable String accountNumber) {
		List<TransactionDTO> transactions = transactionService.getLast10Transactions(accountNumber);
		return ResponseEntity.ok(transactions);
	}

}
