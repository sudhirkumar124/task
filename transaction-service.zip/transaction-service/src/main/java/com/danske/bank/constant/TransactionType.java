package com.danske.bank.constant;

public enum TransactionType {
	DEPOSIT, WITHDRAWAL;

	public static TransactionType parse(String type) {
		return TransactionType.valueOf(type.toUpperCase());

	}
}
