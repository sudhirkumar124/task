package com.danske.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.danske.bank.dto.TransactionDTO;
import com.danske.bank.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionRepository transactionRepository;

	@Override
	public TransactionDTO createTransaction(TransactionDTO transactionDTO) {
		// Implement the logic to create a new transaction and save it to the repository
		// Map the TransactionDTO to the entity and vice versa
		// Return the created TransactionDTO
		return transactionDTO;
	}

	@Override
	public List<TransactionDTO> getLast10Transactions(String accountNumber) {
		// Implement the logic to retrieve the last 10 transactions for the provided
		// Map the entities to TransactionDTOs
		// Return the list of TransactionDTOs
		return null;
	}
}
