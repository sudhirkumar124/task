package com.danske.bank.service;

import java.util.List;

import com.danske.bank.dto.TransactionDTO;

public interface TransactionService {
	/**
	 * Creates a new transaction for the provided account.
	 *
	 * @param transactionDTO contains transaction details.
	 * @return The created TransactionDTO.
	 */
	TransactionDTO createTransaction(TransactionDTO transactionDTO);

	/**
	 * Retrieves the last 10 transactions for the specified account.
	 *
	 * @param accountNumber for which transactions need to be fetched.
	 * @return A list of TransactionDTO representing the last 10 transactions.
	 */
	List<TransactionDTO> getLast10Transactions(String accountNumber);
}
